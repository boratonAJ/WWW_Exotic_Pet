import plotly.express as px

def plot_sentiment_distribution(df):
    return px.histogram(df, x="sentiment_score")
