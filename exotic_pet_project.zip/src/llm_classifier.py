# Mock LLM classifier (replace with OpenAI API)
def classify_themes_llm(texts):
    results = []
    for t in texts:
        t = t.lower()
        if "illegal" in t:
            results.append("Legal Risk")
        elif "danger" in t:
            results.append("Safety")
        else:
            results.append("General")
    return results
