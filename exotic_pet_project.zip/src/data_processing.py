import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

analyzer = SentimentIntensityAnalyzer()

def load_and_prepare_data(file):
    df = pd.read_csv(file)

    if "text_content" not in df.columns:
        df["text_content"] = df.iloc[:, 0]

    df["sentiment_score"] = df["text_content"].apply(
        lambda x: analyzer.polarity_scores(str(x))["compound"]
    )

    return df
