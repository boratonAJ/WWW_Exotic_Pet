def simple_entity(text):
    return "animal" if "tiger" in text.lower() else "unknown"
