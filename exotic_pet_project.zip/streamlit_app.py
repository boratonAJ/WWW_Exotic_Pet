# Streamlit App Entry
import streamlit as st
import pandas as pd
from src.data_processing import load_and_prepare_data
from src.visualizations import plot_sentiment_distribution
from src.llm_classifier import classify_themes_llm

st.title("Exotic Pet Dashboard (LLM Enhanced)")

file = st.file_uploader("Upload CSV", type=["csv"])
if file:
    df = load_and_prepare_data(file)

    st.plotly_chart(plot_sentiment_distribution(df))

    if st.button("Run LLM Theme Classification"):
        df["llm_theme"] = classify_themes_llm(df["text_content"])
        st.dataframe(df[["text_content", "llm_theme"]].head())
